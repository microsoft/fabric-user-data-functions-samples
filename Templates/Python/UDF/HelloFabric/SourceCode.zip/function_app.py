import datetime
import fabric.functions
import logging

app = fabric.functions.FabricApp()

@app.function("hello_fabric")
def hello_fabric(name: str) -> str:
    logging.info('Python UDF trigger function processed a request.')

    return f"Welcome to Fabric Functions, {name}, at {datetime.datetime.now()}!"
