# Fabric Python Function


This is a sample function using python.

Steps to run this project:
1. Ensure the most up to date version of azure functions core tools are installed `https://learn.microsoft.com/en-us/azure/azure-functions/functions-run-local?tabs=windows%2Cisolated-process%2Cnode-v4%2Cpython-v2%2Chttp-trigger%2Ccontainer-apps&pivots=programming-language-python#install-the-azure-functions-core-tools`.
2. Install Python 3.11 and add it to your PATH environment variable (you can download from https://www.python.org/downloads/windows/).
3. You must have the latest ODBC driver(18) installed (you can download from https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server?view=sql-server-ver16)
4. Configure your first function.
5. Create a virtual environment for the python sample. In VSCode, this can be done through installing the Python extension in the VSCode marketplace and then using the shortcut Ctrl+Shift+P to find the task "Python: Create Environment", clicking the Venv environment type, picking the python version you downloaded, and then selecting requirements.txt as the dependencies to install.
6. Hit `F5` or open the debugging window in VSCode to run and debug the function.

