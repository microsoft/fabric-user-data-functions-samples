# Welcome to your Fabric FunctionSet
The Fabric FunctionSet allows you to write, debug code.

# Prerequisites
* Visual Studio Code – [Download Visual Studio Code - Mac, Linux, Windows](https://code.visualstudio.com/download)
* For Fabric App Development:
  *  .NET 8 – [Download .NET 8.0 (Linux, macOS, and Windows) (microsoft.com)](https://dotnet.microsoft.com/en-us/download/dotnet/8.0)
  *  Azure Functions Core Tools – [Develop Azure Functions locally using Core Tools | Microsoft Learn](https://learn.microsoft.com/en-us/azure/azure-functions/functions-run-local?tabs=windows%2Cisolated-process%2Cnode-v4%2Cpython-v2%2Chttp-trigger%2Ccontainer-apps&pivots=programming-language-csharp#install-the-azure-functions-core-tools)



# Feedback
We appreciate all feedback and bug reports! If you experience any problems, have general feedback, or have new ideas, please don’t hesitate to reach out. The Fabric Extension has a `Feedback` section at the bottom.

# TroubleShooting

* If nothing happens if you click Open In VSCode in the portal: VSCode must be installed on your machine
* If you see error squiggles or other errors the first time you open a FunctionSet, it could be because not all FunctionSet dependencies have been put on your machine. This occurs via a .Net Restore, which is triggered by a Build (Shift-Ctrl-B), which is triggered by F5: Start debugging). If that doesn't work, please try opening the terminal, navigating to this directory, and then running `dotnet restore`.
* If you get NU1101: Unable to find package, it could be because the packages to restore (from nuget.org) are not reachable.
        To see the package sources
         `dotnet nuget list source`
    
    To add nuget as a source:

    `dotnet nuget add source https://api.nuget.org/v3/index.json --name nuget.org`


