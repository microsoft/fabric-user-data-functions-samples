using Microsoft.Extensions.Hosting;
using Microsoft.Azure.Functions.Worker.Extensions.Fabric.Extensions;

var host = new HostBuilder()
    .ConfigureFabricWorkerDefaults()
    .Build();

host.Run();
