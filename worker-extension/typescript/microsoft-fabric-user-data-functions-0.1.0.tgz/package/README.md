# Fabric Functions TypeScript Extension

A TypeScript extension library for Microsoft Fabric Functions.

## Installation

```bash
npm install
```

## Development

### Build the library
```bash
npm run build
```

### Watch mode (rebuild on changes)
```bash
npm run build:watch  
```

### Run tests
```bash
npm test
```

### Run tests in watch mode
```bash
npm run test:watch
```

### Lint code
```bash
npm run lint
```

### Fix linting issues
```bash
npm run lint:fix
```

## Usage

```typescript
import FabricTypeScriptExtension from '@microsoft/fabric-functions-typescript-extension';

const extension = new FabricTypeScriptExtension({
  enableLogging: true,
  timeout: 30000
});

extension.initialize();
```

## Project Structure

```
src/
├── index.ts          # Main entry point
└── __tests__/        # Test files
dist/                 # Compiled JavaScript output
```

## Contributing

1. Make your changes in the `src/` directory
2. Add tests in `src/__tests__/`
3. Run `npm test` to ensure all tests pass
4. Run `npm run build` to compile